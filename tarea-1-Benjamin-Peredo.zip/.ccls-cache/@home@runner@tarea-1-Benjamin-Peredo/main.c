#include "tdas/list.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct{
  int hora;
  int minuto;
} HoraAten;

typedef struct{
  char nombre[50];
  int edad;
  char sintomas[50];
  char prioridad[10];
  HoraAten tiempo;
} Ingresado;

// Función para limpiar la pantalla
void limpiarPantalla() { system("clear"); }

void presioneTeclaParaContinuar() {
  puts("Presione una tecla para continuar...");
  getchar(); // Consume el '\n' del buffer de entrada
  getchar(); // Espera a que el usuario presione una tecla
}

// Menú principal
void mostrarMenuPrincipal() {
  limpiarPantalla();
  puts("========================================");
  puts("     Sistema de Gestión Hospitalaria");
  puts("========================================");

  puts("1) Registrar paciente");
  puts("2) Asignar prioridad a paciente");
  puts("3) Mostrar lista de espera");
  puts("4) Atender al siguiente paciente");
  puts("5) Mostrar pacientes por prioridad");
  puts("6) Salir");
}

void registrar_paciente(List *pacientes) {
  Ingresado *paciente = (Ingresado *) malloc(sizeof(Ingresado)); 
  printf("Registrar nuevo paciente\n");
  printf("Ingrese el nombre del paciente: ");
  scanf(" %[^\n]s", paciente->nombre);
  printf("Ingrese la edad del paciente: ");
  scanf("%d", &paciente->edad);
  printf("Ingrese los síntomas del paciente: ");
  scanf(" %[^\n]s", paciente->sintomas);

  time_t horaActual;
  time(&horaActual);
  struct tm *local_time = localtime(&horaActual);
  local_time->tm_hour += 20;
  if (local_time->tm_hour >= 24)
      local_time->tm_hour -= 24;
  paciente->tiempo.hora = local_time->tm_hour;
  paciente->tiempo.minuto = local_time->tm_min;

  strcpy(paciente->prioridad , "Baja");
  list_pushBack(pacientes, paciente);
  printf("Paciente registrado con éxito.\n");
}

void asignar_prioridad(List *pacientes, List *prioridad_alta, List *prioridad_media, List *prioridad_baja){
  char comparar[50];  // Se asigna el nombre del paciente a comparar
  char prioridad[10];  // Se asigna la prioridad del paciente a comparar
  Ingresado *paciente;
  paciente = (Ingresado *)list_first(pacientes);  //se asigna a paciente el primero de la lista
  if (paciente == NULL){  // si no existen pacientes en al lista
    printf("No hay pacientes registrados.\n");
    return;
  }
  
  printf("Ingrese el nombre del paciente a asignar prioridad: ");
  scanf(" %[^\n]s", comparar);  // se escanea el nombre del paciente a comparar
  
  while(strcmp(paciente->nombre, comparar) != 0)   // se compara el nombre del paciente con el nombre ingresado
  {  
    paciente = (Ingresado *)list_next(pacientes);
    if (paciente == NULL)   // si no existe el paciente en la lista
    {  
      printf("No existe el paciente.\n");
      return;
    }
  }
    
  if (strcmp(paciente->nombre, comparar) == 0)    //si existe el nombre del paciente en al lista
  {   
    printf("Ingrese la prioridad del paciente [Alta, Media, Baja]: ");
    scanf(" %[^\n]s", prioridad);   // se escanea la prioridad del paciente
    strcpy(paciente->prioridad, prioridad);    // se copia la prioridad del paciente en la lista
    
    if (strcmp(paciente->prioridad, "Alta") == 0){// si la prioridad es alta
      list_pushBack(prioridad_alta, paciente);
      list_popCurrent(pacientes);
    }
    if (strcmp(paciente->prioridad, "Media") == 0){
      list_pushBack(prioridad_media, paciente);
      list_popCurrent(pacientes);
    }
    if (strcmp(paciente->prioridad, "Baja") == 0){
      list_pushBack(prioridad_baja, paciente);
      list_popCurrent(pacientes);
    }
  }
}

void mostrar_lista_pacientes(List *prioridad_alta, List *prioridad_media, List *prioridad_baja) {
  // Mostrar pacientes en la cola de espera
  printf("Pacientes en lista de espera: \n");
  printf("-----------------------------------\n");

  Ingresado *aux;
  aux = (Ingresado *)list_first(prioridad_alta);

  if (aux == NULL){
    printf("No hay pacientes con prioridad ALTA\n");
  }
  
  while (aux != NULL){
    printf("Nombre: %s\n", aux->nombre);
    printf("Edad: %d\n", aux->edad);
    printf("Síntomas: %s\n", aux->sintomas);
    printf("Prioridad: %s\n", aux->prioridad);
    printf("Hora de llegada: %02d:%02d\n", aux->tiempo.hora, aux->tiempo.minuto);
    aux = (Ingresado *)list_next(prioridad_alta);
  }
printf("-----------------------------------\n\n");

  aux = (Ingresado *)list_first(prioridad_media);

  if (aux == NULL){
    printf("-----------------------------------\n");
    printf("No hay pacientes con prioridad MEDIA\n");
    }
  
  while (aux != NULL){
    printf("-----------------------------------\n");
    printf("Nombre: %s\n", aux->nombre);
    printf("Edad: %d\n", aux->edad);
    printf("Síntomas: %s\n", aux->sintomas);
    printf("Prioridad: %s\n", aux->prioridad);
    printf("Hora de llegada: %02d:%02d\n", aux->tiempo.hora, aux->tiempo.minuto);
    aux = (Ingresado *)list_next(prioridad_media);
  }
  printf("-----------------------------------\n\n");

  aux = (Ingresado *)list_first(prioridad_baja);

  if (aux == NULL){
    printf("-----------------------------------\n");
    printf("No hay pacientes con prioridad BAJA\n");
    }
  
  while (aux != NULL){
    printf("-----------------------------------\n");
    printf("Nombre: %s\n", aux->nombre);
    printf("Edad: %d\n", aux->edad);
    printf("Síntomas: %s\n", aux->sintomas);
    printf("Prioridad: %s\n", aux->prioridad);
    printf("Hora de llegada: %02d:%02d\n\n", aux->tiempo.hora, aux->tiempo.minuto);
    aux = (Ingresado *)list_next(prioridad_baja);
  }
  printf("-----------------------------------\n");

  // Aquí implementarías la lógica para recorrer y mostrar los pacientes
}

int main() {
  char opcion;
  List *pacientes = list_create(); // puedes usar una lista para gestionar los pacientes
  List *prioridad_alta = list_create();
  List *prioridad_media = list_create();
  List *prioridad_baja = list_create();

  do {
    mostrarMenuPrincipal();
    printf("Ingrese su opción: ");
    scanf(" %c", &opcion); // Nota el espacio antes de %c para consumir el
                           // newline anterior

    switch (opcion) {
    case '1':
      registrar_paciente(pacientes);
      break;
    case '2':
      // Lógica para asignar prioridad
      asignar_prioridad(pacientes, prioridad_alta, prioridad_media, prioridad_baja);
      break;
    case '3':
      mostrar_lista_pacientes(prioridad_alta, prioridad_media, prioridad_baja);
      break;
    case '4':
      // Lógica para atender al siguiente paciente
      break;
    case '5':
      // Lógica para mostrar pacientes por prioridad
      break;
    case '6':
      puts("Saliendo del sistema de gestión hospitalaria...");
      break;
    default:
      puts("Opción no válida. Por favor, intente de nuevo.");
    }
    presioneTeclaParaContinuar();

  } while (opcion != '6');

  // Liberar recursos, si es necesario
  list_clean(pacientes);

  return 0;
}
